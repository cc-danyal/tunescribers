import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.remote.server.DriverFactory as DriverFactory
import org.openqa.selenium.WebDriver as WebDriver
import java.util.List as List
import java.util.ArrayList as ArrayList
import org.openqa.selenium.By as By
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.remote.RemoteWebDriver as RemoteWebDriver
import org.openqa.selenium.remote.RemoteWebElement as RemoteWebElement
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

WebUI.openBrowser('https://tunescribers.com/')

WebUI.maximizeWindow()

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Worlds Finest Music Tran_77530f/a_Login'))

WebUI.setText(findTestObject('Object Repository/Page_Tunescribers  Login/input_Please enter email and password_username'), 
    'muhammad.danyal@cooperativecomputing.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Tunescribers  Login/input_Please enter email and password_password'), 
    'he6LtG7CITvGDhmDyKTJqw==')

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Login/input_Forgot your password_button text-cent_363f13'))

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Customer Dashboard/a_Home'))

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Worlds Finest Music Tran_77530f/p_Examples httpsyoutubeQse0LMVAzBEhttpswwwy_9a24e6'))

WebUI.setText(findTestObject('Object Repository/Page_Tunescribers  Worlds Finest Music Tran_77530f/input_Enter the songs YouTube web address_link'), 
    'https://www.youtube.com/watch?v=6jmnASVqZMU')

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Worlds Finest Music Tran_77530f/input_Enter the songs YouTube web address_b_4fcef0'))

WebUI.delay(5)

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Worlds Finest Music Tran_77530f/input_Cancel_continue'))

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Step/a-Next_Youtube'))

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Step/label_I own the copyright'))

WebUI.setText(findTestObject('Object Repository/Page_Tunescribers  Step/input_I own the copyright_copyrightfield'), 'Automated Copyright')

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Step/a_Next_1_Youtube'))

WebUI.doubleClick(findTestObject('Object Repository/Page_Tunescribers  Step/input_Song title_title'))

WebUI.setText(findTestObject('Object Repository/Page_Tunescribers  Step/input_Song title_title'), 'Automated Youtube Song Using Coupon Code')

//WebUI.setText(findTestObject('Object Repository/Page_Tunescribers  Step/textarea_Any other special instructions_special'), 
//    'This is Automated Text for Special Insturction')
WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Step/a_Next_1_2_Youtube'))

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Step/a_Next_1_2_3_Youtube'))

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Step/input_I agree to the above and to theand_terms'))

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Step/a_Continue to Checkout'))

WebUI.click(findTestObject('Object Repository/a_Checkout'))

WebUI.setText(findTestObject('Object Repository/input_Discount Code_discount'), 'madiha')

WebUI.click(findTestObject('Object Repository/button_Validate Code'))

WebElement checkoutSubmit = WebUiCommonHelper.findWebElement(findTestObject('Object Repository/Page_Tunescribers  Checkout/input_Previous_submit'), 
    30)

WebUI.executeJavaScript('arguments[0].click()', Arrays.asList(checkoutSubmit))

WebUI.closeBrowser()

