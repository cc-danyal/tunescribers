import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.remote.server.DriverFactory as DriverFactory
import org.openqa.selenium.WebDriver as WebDriver
import java.util.List as List
import java.util.ArrayList as ArrayList
import org.openqa.selenium.By as By
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.remote.RemoteWebDriver as RemoteWebDriver
import org.openqa.selenium.remote.RemoteWebElement as RemoteWebElement
import org.openqa.selenium.JavascriptExecutor
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory

WebUI.openBrowser('https://uat.tunescribers.com/')

WebUI.maximizeWindow()

//WebDriver driver = DriverFactory.getWebDriver()
WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Worlds Finest Music Tran_77530f/a_Login'))

WebUI.setText(findTestObject('Object Repository/Page_Tunescribers  Login/input_Please enter email and password_username'), 
    'muhammad.danyal@cooperativecomputing.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Tunescribers  Login/input_Please enter email and password_password'), 
    'he6LtG7CITvGDhmDyKTJqw==')

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Login/input_Forgot your password_button text-cent_363f13'))

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Customer Dashboard/a_Songs for Sale'))

WebUI.navigateToUrl('https://uat.tunescribers.com/catalog')

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Songs For Sale/u_Karakoram - Toofaan'))

WebUI.switchToWindowTitle('Tunescribers | Karakoram - Toofaan | Sheet Music')

WebUI.click(findTestObject('Object Repository/Page_Tunescribers  Karakoram - Toofaan  She_e70c6a/img_Check out todays special deals_cartButtons'))

WebUI.click(findTestObject('Page_Tunescribers  Cart/a_Checkout'))

WebUI.setText(findTestObject('Object Repository/input_Discount Code_discount'), 'madiha')

WebUI.click(findTestObject('Object Repository/button_Validate Code'))

WebElement checkoutSubmit = WebUiCommonHelper.findWebElement(findTestObject('Object Repository/Page_Tunescribers  Checkout/input_Previous_submit'), 
    30)

WebUI.executeJavaScript('arguments[0].click()', Arrays.asList(checkoutSubmit))

WebUI.closeBrowser()
