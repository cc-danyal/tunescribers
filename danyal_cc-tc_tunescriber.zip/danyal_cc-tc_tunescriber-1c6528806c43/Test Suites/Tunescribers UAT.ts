<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Tunescribers UAT</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>d636195d-65b2-47b1-add1-b6c8c200ce0a</testSuiteGuid>
   <testCaseLink>
      <guid>40f03780-fc19-4358-8090-6f87029b682f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Youtube Song Order</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ee3f7d65-387d-4c23-abf3-98cd0562bb5a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Youtube song Order Using Coupon Code</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>46464df3-5f80-4a0e-a6ea-616048877fc3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Song for Sale Order</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6c6a773a-50ec-4a5f-936b-065727115bee</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Song For Sale Order Using Points</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>29132413-5070-4307-b4be-f66ca1347300</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Song For Sale Order Using Coupon Code</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d2d5abf8-a294-47e9-b875-05897034f19a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Product Code Order</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c715657f-79e3-446d-9bbc-76c11192abb0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Product Code Order Using Coupon code</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f7eec0d5-6f71-4a86-b3b9-7bcc255b1006</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Redirection of all the Pages</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
