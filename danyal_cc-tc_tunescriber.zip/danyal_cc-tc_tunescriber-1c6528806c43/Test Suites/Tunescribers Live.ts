<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Tunescribers Live</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>c12c1d37-7d7e-473a-93bc-addae567cfcd</testSuiteGuid>
   <testCaseLink>
      <guid>7d6ef45e-4c1e-488f-9a50-3474ebda7e64</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers Live/Automated Product Code Order</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>50c898a1-96f3-434e-a6ac-52bc64dbccb8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers Live/Automated Product Code Order Using Coupon code</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b2e7f051-0bc4-4612-8149-22faa227efd9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers Live/Automated Song for Sale Order</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>801e6533-90e8-4c42-b219-7e48b68edfc6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers Live/Automated Song For Sale Order Using Coupon Code</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>eb5a73a4-7b0c-4d98-9776-fa3c2abdc785</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers Live/Automated Song For Sale Order Using Points</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9ea5fde1-7424-421d-bd45-c00fb87eb551</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers Live/Automated Youtube Song Order</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d9f6e0aa-16c0-47ba-8efd-04e943e907c2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers Live/Automated Youtube song Order Using Coupon Code</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
