<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test CMD Suit</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>9282b48f-ab05-43b9-b6ea-6cb7e9a27cb9</testSuiteGuid>
   <testCaseLink>
      <guid>11fbd921-1d8a-4557-8811-19961e36d951</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tunescribers UAT/Automated Youtube song Order Using Coupon Code</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
