<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Next_1_2_Youtube</name>
   <tag></tag>
   <elementGuidId>83f0db17-7637-4c5d-9f10-2d7dc2966c21</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'skipStep3']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='btnStep3']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>skipStep3</value>
   </webElementProperties>
</WebElementEntity>
