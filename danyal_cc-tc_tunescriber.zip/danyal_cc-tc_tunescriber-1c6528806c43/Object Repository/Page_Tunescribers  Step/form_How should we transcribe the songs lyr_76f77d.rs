<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>form_How should we transcribe the songs lyr_76f77d</name>
   <tag></tag>
   <elementGuidId>26761119-4527-41ce-8737-2bf49c859d57</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='frmOrder']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>form</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>method</name>
      <type>Main</type>
      <value>POST</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>action</name>
      <type>Main</type>
      <value>https://uat.tunescribers.com/video-cart</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>accept-charset</name>
      <type>Main</type>
      <value>UTF-8</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>form</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>autocomplete</name>
      <type>Main</type>
      <value>off</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>frmOrder</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>enctype</name>
      <type>Main</type>
      <value>multipart/form-data</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
            
                
                
            
            
                 How should we transcribe the song’s lyrics?
                
                        
                    
                        Song has no lyrics
                    
                
                
                        
                    
                        I don't have the lyrics
                    
                    Are you sure? We will try our best to figure out the lyrics, but mistakes are possible.
                
                
                        
                    
                        Get lyrics from a file.
                    
                    
                
                
                    
                    
                        Get lyrics from a web page.
                    
                    
                
                
                        
                    
                        I’ll type/paste the lyrics.
                    
                    
                        
                        
                    
                
                
                
                    Previous
                    Next
                    CANCEL ORDER
                
            
            
                
                Who owns the copyright to this song?
                    
                        
                            
                            
                                The song is in the public domain (traditional song, or published in 1924 or earlier)
                            
                        
                        
                            
                            
                                Someone else owns the copyright
                            
                        
                         
                        
                        
                            I own the copyright
                        
                        
                            
                            
                            
                                Make money with Tunescribers! When we’re finished with this project, we can sell your sheet music in our Songs For Sale section and pay you royalties. Learn how it works
                            
                            
                        
                    
                
                    Previous
                    Next
                    CANCEL ORDER

                
            
            
                 
                    Please help us do a great job! Answer as many of these questions as you can. Or if you prefer, just skip this page and leave it to us to create your sheet music.
                
                
                    
                    To learn more about any of these, just mouse over the  symbol.
                
                 

    
        
    
    
        
            Song title:
        
        
            
        
    
    
        
            Written by:
        
        
            
        
    
    
        
            Performed by:
        
        
            
        
    
 
    
        
        What do you want us to do with your song?
    

    
        
            
            
            Arrange it
            
        
        
            
                
                    
                    Transcribe it exactly as it’s played
                    
            
        
    

    
        
            
            How complex do you want the arrangement to be?
        
        
            
                
                    
                    
                        Normal
                    
                
            
            
                
                    
                    
                        Simplified
                    
                
            
        
    
    
        
            
            What instruments do you want?
        
        
            
                                    
                        
                            
                            
                                Piano and vocals
                                (example)
                                                                                                This is the most popular type of arrangement
                                                            
                        
                    
                                        
                        
                            
                            
                                Guitar and vocals
                                (example)
                                                                                            
                        
                    
                                        
                        
                            
                            
                                Chords and vocals (a “lead sheet” or “fake sheet”)
                                (example)
                                                                                            
                        
                    
                                        
                        
                            
                            
                                Piano solo 
                                (example)
                                                                                            
                        
                    
                                        
                        
                            
                            
                                Guitar solo
                                (example)
                                                                                            
                        
                    
                                        
                        
                            
                            
                                All instruments and vocals
                                (example)
                                                                An extra fee may be charged, we’ll let you know.
                                                                                            
                        
                    
                                        
                        
                            
                            
                                Some instruments and/or vocals:
                                An extra fee may be charged, we’ll let you know.
                            
                            
                        
                    
                
            
        
    
    
        
            
            Do you want a guitar or guitar-like instrument (bass, ukulele, etc.) in your transcription?
        
        
            
                
                    
                    Yes
                    
                
            
            
                
                    
                    No
                    
                
            
        
    
    
        
            
            How do you want the guitar part to be notated?
        
        
            
                                
                    
                        
                        
                            Standard notation
                        
                        
                        (example)
                        
                                                    
                    
                
                                
                    
                        
                        
                            Tablature
                        
                        
                        (example)
                        
                                                        +$5.00
                                                    
                    
                
                                
                    
                        
                        
                            Standard notation AND tablature
                        
                        
                        (example)
                        
                                                        +$5.00
                                                    
                    
                
                            
        
    
    
        
            
            What key do you want the song in?
        
        

            
                
                
                    Keep in the original key
                
                            
        
                
            
                
                
                    Transpose to a key that’s easier to play
                    
                                                                        +$5.00
                                            
                
                
                
            
        
                
            
                
                
                    Transpose to key of
                    
                                                
                                                                        +$5.00
                                            
                
                
                
            
        
            
    
        
            
            Do you want separate part sheets for each instrument and vocal?
        
        
            
                
                
                    No
                
            
        
        
            
                
                
                    Yes
                
                
                (example)
                
                                        +$5.00
                                    
            
        
    
    
        
            
            Do you want files that can be imported into music editing programs?  Check all that you want.
        
                
            
                 .MUSX for Finale
                
                
                
                                        +$5.00
                                    
            
        

                
            
                 .GP for GuitarPro 
                
                
                                        +$5.00
                                    
                
            
        

                
            
                 .MSCZ For Musescore
                
                
                
                                        +$5.00
                                    
            
        

                
            
                 .SIB for Sibelius 
                
                
                
                                        +$5.00
                                    
            
        

                            
                
                     .MIDI file
                    
                    
                                                +$5.00                                             
                    
                
            
                    
                
                     Separate .MIDI files for each instrument 
                    
                    
                                                +$5.00  more than 1 .MIDI file                                             
                    
                
            
            
    
        
            
            Do you want a slowed-down version of the MP3 file, to help you learn to play the song?
        
        
            
                
                
                    No
                
            
        
                
            
                
                
                    Yes, 80% of normal speed
                    
                                                +$5.00
                                            
                
                
                
            
        
                
            
                
                
                    Yes, half normal speed
                    
                                                +$5.00
                                            
                
                
                
            
        
            
    
        
            Any other special instructions?
        
        
            
                
            
        
    

                
                    Previous
                    Next
                    CANCEL ORDER
                
            
            
                Terms and Conditions
                
                    We take copyright law very seriously, and will not do anything to compromise the rights of songwriters and
                        performers.  So, here’s the deal.  If you have a performance license for the song, either because you wrote it or
                        someone else licensed performance rights to you, then we will transcribe it and you can do anything you like
                        with it.  But if you don’t have a performance license, then we will still do the transcription for you, but it will
                        be as a service for your personal and private use, and you may not sell, distribute, publish, publicly perform,
                        or do anything with our work that would violate the rights of the music’s rightful owner. 
                    
                          I agree to the above, and to the  
                        Terms of Service and
                        Privacy Policy.
                    
                
                
                    Previous
                    Continue to Checkout
                    Continue to Checkout
                    CANCEL ORDER
                
            
            
                 How quickly do you want us to do this work?
                
                    
                        
                        
                                                    Normal delivery, in 8 days 
                        
                        
                        
                            Rush Job, delivery in 2 days  (add $88)
                            
                            
                            
                        
                    
                
                
                    Previous
                    Next
                    CANCEL ORDER
                
            
            
                YOUR ORDER
                                                        
                        Song:
                       Automated Youtube Song
                    
                                        
                        YouTube Link:
                        https://www.youtube.com/watch?v=6jmnASVqZMU
                    
                                        
                        Artist:
                        LoloYodel
                    
                                        
                        Transcribe:
                        00:00 to
                        13:06
                    
                    
                        Duration:
                        13:06 min
                    
                    
                        Lyrics:
                        Song has no lyrics
                    
                     
                        Copyright:
                        Automated Copyright
                    
                    
                        
                        
                    
                    
                        
                        
                    
                    
                        Cost:
                        $ 353.05
                    
                
                    
                        Arrange piano and vocals
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
                    
                        
                    
            
        
    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;frmOrder&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//form[@id='frmOrder']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form</value>
   </webElementXpaths>
</WebElementEntity>
