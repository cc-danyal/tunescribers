<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Transcribe it exactly as its played</name>
   <tag></tag>
   <elementGuidId>6bc493bb-542f-4f97-bf3d-b770bf957a60</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[@onclick=&quot;jQuery('.acc-event-arrange > label').removeClass('active-label'); jQuery(this).addClass('active-label');jQuery('.complexArrange').hide();jQuery('#arrangeIt').attr('checked',false);jQuery('#transcribe').attr('checked',true);jQuery('#yesGuitar').attr('checked',true);jQuery('#song-10').attr('checked',true);&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>transcribe</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>jQuery('.acc-event-arrange > label').removeClass('active-label'); jQuery(this).addClass('active-label');jQuery('.complexArrange').hide();jQuery('#arrangeIt').attr('checked',false);jQuery('#transcribe').attr('checked',true);jQuery('#yesGuitar').attr('checked',true);jQuery('#song-10').attr('checked',true);</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Transcribe it exactly as it’s played
                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;accordion&quot;)/div[@class=&quot;panel-default&quot;]/div[@class=&quot;panel-default&quot;]/a[@class=&quot;acc-event-arrange&quot;]/label[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//label[@onclick=&quot;jQuery('.acc-event-arrange > label').removeClass('active-label'); jQuery(this).addClass('active-label');jQuery('.complexArrange').hide();jQuery('#arrangeIt').attr('checked',false);jQuery('#transcribe').attr('checked',true);jQuery('#yesGuitar').attr('checked',true);jQuery('#song-10').attr('checked',true);&quot;]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='accordion']/div[2]/div/a/label</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Arrange it'])[1]/following::label[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Normal'])[1]/preceding::label[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Transcribe it exactly as it’s played']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a/label</value>
   </webElementXpaths>
</WebElementEntity>
